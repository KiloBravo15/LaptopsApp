﻿using System.Windows;

namespace Buchnat.LaptopsApp
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
