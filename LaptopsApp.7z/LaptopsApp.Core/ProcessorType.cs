﻿namespace Buchnat.LaptopsApp.Core
{
    public enum ProcessorType
    {
        Intel, 
        AMD,
        Apple
    }
}
