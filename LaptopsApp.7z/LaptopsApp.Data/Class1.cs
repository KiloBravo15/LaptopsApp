﻿namespace LaptopsApp.Data
{
    public class Class1
    {

    }
}
