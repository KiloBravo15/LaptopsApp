﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Buchnat.LaptopsApp.DAOSQL.Migrations
{
    /// <inheritdoc />
    public partial class Update1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
